﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newtonsoft.Json;

namespace ChatBot1.Model
{
    public class FinanceInfo
    {
        [JsonProperty("date")]
        public DateTime Date { get; set; }
        [JsonProperty("exchangeRate")]
        public List<ExchangeRate> ListExchangeRate { get; set; }
    }

    public class ExchangeRate
    {
        [JsonProperty("currency")]
        public string Currency { get; set; }
        [JsonProperty("saleRateNB")]
        public double SellNB { get; set; }
        [JsonProperty("purchaseRateNB")]
        public double BuyNB { get; set; }
        [JsonProperty("saleRate")]
        public double Sell { get; set; }
        [JsonProperty("purchaseRate")]
        public double Buy { get; set; }
    }
}