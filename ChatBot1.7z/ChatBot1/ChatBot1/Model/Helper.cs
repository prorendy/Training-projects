﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newtonsoft.Json;
using System.Net;

namespace ChatBot1.Model
{
    public static class Helper
    {
        public static string DateHandler(DateTime dateTime)
        {
            if (dateTime > DateTime.Now)
                return "Sorry, I don't know future=)";
            if (dateTime.AddYears(4) < DateTime.Now)
                return "Sorry, I remember only last 4 years";
            var webClient = new WebClient();
            string Url = string.Format("https://api.privatbank.ua/p24api/exchange_rates?json&date={0}.{1}.{2}", dateTime.Day, dateTime.Month, dateTime.Year);
            string answer = webClient.DownloadString(Url);
            FinanceInfo financeInfo = JsonConvert.DeserializeObject<FinanceInfo>(answer);
            answer = string.Format("Курс основних валют на {0}:\r\n\r\n", dateTime.ToShortDateString());
            foreach (var item in financeInfo.ListExchangeRate)
            {
                if ((item.Currency == "USD") || (item.Currency == "EUR") || (item.Currency == "RUB"))
                {
                    answer += (string.Format("1 {0} = {1}..{2} UAH\r\n\r\n", item.Currency, item.Buy, item.Sell));
                }
            }
            return answer;
        }

        public static string CityHandler(string city)
        {
            try
            {
                var webClient = new WebClient();
                string Url = string.Format("http://api.openweathermap.org/data/2.5/weather?q={0}&appid=00e8ebcb00bdfd3e3a997bd39770efb8", city);
                string answer = webClient.DownloadString(Url);
                WeatherInfo weather = JsonConvert.DeserializeObject<WeatherInfo>(answer);
                answer = string.Format("The weather in {0}:\r\n\r\n", city) + weather.ToString();
                return answer;
            }
            catch
            {
                return "Sorry, Bro. I don't understand you=((";
            }
        }
    }
}