﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newtonsoft.Json;

namespace ChatBot1.Model
{
    public class WeatherInfo
    {
        [JsonProperty("main")]
        public Main Main { get; set; }
        [JsonProperty("wind")]
        public Wind Wind { get; set; }
        [JsonProperty("clouds")]
        public Clouds Clouds { get; set; }
        [JsonProperty("name")]
        public string Name { get; set; }

        public override string ToString()
        {
            string answerString = string.Format("Temperature = {0}C\r\n\r\n", Main.Temperature - 273.15, Main.Pressure);
            answerString += string.Format("Pressure = {0}Torr\r\n\r\n", Main.Pressure/ 1.33322);
            answerString += string.Format("Humidity = {0}%\r\n\r\n", Main.Humidity);
            answerString += string.Format("Speed of wind = {0}m/s\r\n\r\n", Wind.Speed);
            return answerString;
        }
    }

    public class Main
    {
        [JsonProperty("temp")]        
        public double Temperature { get; set; }
        [JsonProperty("pressure")]
        public int Pressure { get; set; }
        [JsonProperty("humidity")]
        public int Humidity { get; set; } 
    }

    public class Wind
    {
        [JsonProperty("speed")]
        public double Speed { get; set; }
        [JsonProperty("deg")]
        public int Deg { get; set; }
    }

    public class Clouds
    {
        [JsonProperty("all")]
        public int All { get; set; }
    }

    
}